
class AuthState {
  static bool isLoggedIn = false;
  static String userType = ""; // business / customer

  static bool isBusinessRegistered = false; // 👈 ADD THIS
}